# CCAS Acquisitions Ledger — PBIP Semantic Model

## What's in this folder
`CCAS Acquisitions Ledger.SemanticModel/` is a complete, self-contained Power BI semantic model in TMDL (text) format:
- **Applications** table — 12 weeks × 4 channels of application/approval/booking data, matching the funnel and channel-mix visuals in the prototype.
- **VintageCohorts** table — 6 monthly cohorts with 30/90dpd rates, matching the vintage table in the prototype.
- 5 measures: Total Applications, Total Approvals, Approval Rate %, Cards Booked, Booking Rate %.
- Data is embedded directly in the model (M `#table` source) — **no external database, no local file path, nothing to configure.** It opens and works immediately, on any machine, offline.

This is deliberately **model-only**. The report/visual layer isn't included — here's why, and the two-minute step that gets you there reliably.

## Why the report layer isn't pre-built
The report-visual file format is tied tightly to your exact Power BI Desktop build. Hand-authoring it without testing against your actual Desktop version risks a "file is corrupted" error on open — worse than not having it at all. The fix is simple and guarantees a valid result:

## Setup steps (do this on your office laptop)

1. **Copy the whole `CCAS Acquisitions Ledger.SemanticModel` folder** into a working folder on your machine (e.g. `C:\PBI-Projects\`).
2. Open **Power BI Desktop**.
3. **File → Open → Browse** (not "Open report" — look for **"Power BI project (.pbip)"** in the file type dropdown, or open the `.pbism` file directly if your version supports it). If your Desktop build doesn't show a `.pbip`-style open option, use step 3b instead.
   - **3b (fallback, always works):** File → Get Data → **Blank Query**, or simply create a brand-new blank report, then use **Home → Transform data → Advanced Editor** to paste in the M source from any `partition ... = m` block in the `.tmdl` files under `definition/tables/`. This recreates the same tables manually in a fresh report if the raw project-open path isn't available on your build.
4. Once the model loads, you'll see **Applications** and **VintageCohorts** in the Fields pane with the 5 measures ready to use.
5. Go to **View → Themes → Browse for themes** and import `CCAS_Dark_Ledger_Theme.json` (from the earlier deliverables) so colors match the prototype.
6. Build the first page by hand (or with Copilot in Desktop, if licensed) using `CCAS_Dashboard_Prototype.html` as your visual reference — KPI cards for the 4 measures, a line chart of Applications/Approvals by WeekEndDate, a donut of Channel mix, and a table on VintageCohorts.
7. **Save As → .pbip** (enable this in Desktop under Options → Preview features → "Power BI Project (.pbip) save option" if you don't see it). This generates the correctly-versioned Report folder for *your* exact build — the piece I couldn't safely hand-author.

## What happens next
That saved page is now your real **golden template** — proven to open on your machine, in your Desktop version. Point your Copilot Studio agent at *this* file (not a hypothetical one) going forward, per the narration document. Every future report request clones this validated structure instead of starting blank.
